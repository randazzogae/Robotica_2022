


public class TRY_IT_2_LEFT extends Robot_Left{

	public TRY_IT_2_LEFT(){
		super();
	}

}	