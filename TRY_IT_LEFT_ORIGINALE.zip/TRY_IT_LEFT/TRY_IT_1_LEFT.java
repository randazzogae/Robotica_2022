



public class TRY_IT_1_LEFT extends Robot_Left{

	public TRY_IT_1_LEFT(){
		super();
	}

}	