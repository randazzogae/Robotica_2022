% ----------------------------------------------------------------------
% System:	ECLiPSe Constraint Logic Programming System
% Copyright (C) Imperial College London and ICL 1995-1999
% Version:	$Id: alldiff_strong.pl,v 1.10 2000/05/10 13:07:37 js10 Exp $
%
%	Contents has been moved to lib(fd_global) !
%
% ----------------------------------------------------------------------

:- module(alldiff_strong).

:- reexport
	alldifferent/1,
	alldifferent/2,
	not_among/2
    from fd_global.

