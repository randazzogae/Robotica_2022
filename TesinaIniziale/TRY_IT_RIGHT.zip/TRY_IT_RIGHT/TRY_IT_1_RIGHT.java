

public class TRY_IT_1_RIGHT extends Robot_Right{

	public TRY_IT_1_RIGHT(){
		super();
	}

}